from kafka import KafkaProducer
import kafka
import json
import tweepy
from tweepy import OAuthHandler
from tweepy import Stream
from tweepy.streaming import StreamListener

consumer_key = "Tba4dz6iAhJ8aIlruIVyOgv1H"
consumer_secret = "hrMWxGtZPKjDPhWz6iPVRIXnrJAFofRqW8cCh3lQG9TKXSNUEs"
access_token = "1250167730981998592-RVTbFdCcrbvxl4VWOPh1MMrur0Co0w"
access_secret = "n5K7kaJDMtMChQBqoMtPX957NJNdOyj1nY1O9Kapv5vZk"

hashtag = "corona"
auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

api = tweepy.API(auth)
class KafkaPushListener(StreamListener):
    def __init__(self):
        self.producer = KafkaProducer(bootstrap_servers=['localhost:9092'])

    def on_data(self, data):
        self.producer.send("twitter_stream_" + hashtag +"tweets", data.encode('utf-8'))
        print(data)
        return True

    def on_error(self, status):
        print(status)
        return True


twitter_stream = Stream(auth, KafkaPushListener())

hashStr = "#"+ hashtag

twitter_stream.filter(track=[hashStr])
